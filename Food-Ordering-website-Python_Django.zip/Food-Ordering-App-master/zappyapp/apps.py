from django.apps import AppConfig


class ZappyappConfig(AppConfig):
    name = 'zappyapp'
